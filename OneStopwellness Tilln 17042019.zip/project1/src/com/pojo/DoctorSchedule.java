package com.pojo;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.TreeMap;

public class DoctorSchedule {
private String docname;
public HashMap<String,String> docSlot  = new HashMap<>();
public String getDocname() {
	return docname;
}
public HashMap<String, String> getDocSlot() {
	return docSlot;
}
public void setDocSlot(HashMap<String, String> docSlot) {
	this.docSlot = docSlot;
}
public void setDocname(String docname) {
	this.docname = docname;
}



}
