/**
* 
 */
var state_arr = new Array();


state_arr[0]= "Andhra Pradesh";
state_arr[1]= "Assam";
state_arr[2]="Bihar";
state_arr[3]="Chhattisgarh";
state_arr[4]="Goa";
state_arr[5]="Gujarat";
state_arr[6]="Haryana";
state_arr[7]="Himachal Pradesh";
state_arr[8]="Jammu and Kashmir";
state_arr[9]="Jharkhand";
state_arr[10]="Karnataka";
state_arr[11]="Kerala";
state_arr[12]="Madhya Pradesh";
state_arr[13]="Maharashtra";
state_arr[14]="Manipur";
state_arr[15]="Meghalaya";
state_arr[16]="Mizoram";
state_arr[17]="Nagaland";
state_arr[18]="Odisha";
state_arr[19]="Punjab";
state_arr[20]="Rajasthan";
state_arr[21]="Sikkim";
state_arr[22]="Tamil Nadu";
state_arr[23]="Telangana";
state_arr[24]="Tripura";
state_arr[25]="Uttar Pradesh";
state_arr[26]="Uttarakhand";
state_arr[27]="West Bengal";




var s_a = new Array();

s_a[0]="";

s_a[1]="Adilabad|Anantapur|Chittoor|Kakinada|Guntur|Hyderabad|Karimnagar|Khammam|Krishna|Kurnool|Mahbubnagar|Medak|Nalgonda|Nizamabad|Ongole|Hyderabad|Srikakulam|Nellore|Visakhapatnam|Vizianagaram|Warangal|Eluru|Kadapa";
s_a[2]="Baksa|Barpeta|Bongaigaon|Cachar|Chirang|Darrang|Dhemaji|Dima Hasao|Dhubri|Dibrugarh|Goalpara|Golaghat|Hailakandi|Jorhat|Kamrup|Kamrup Metropolitan|Karbi Anglong|Karimganj|Kokrajhar|Lakhimpur|Marigaon|Nagaon|Nalbari|Sibsagar|Sonitpur|Tinsukia|Udalguri";
s_a[3]="Araria|Arwal|Aurangabad|Banka|Begusarai|Bhagalpur|Bhojpur|Buxar|Darbhanga|East Champaran|Gaya|Gopalganj|Jamui|Jehanabad|Kaimur|Katihar|Khagaria|Kishanganj|Lakhisarai|Madhepura|Madhubani|Munger|Muzaffarpur|Nalanda|Nawada|Patna|Purnia|Rohtas|Saharsa|Samastipur|Saran|Sheikhpura|Sheohar|Sitamarhi|Siwan|Supaul|Vaishali|West Champaran";
s_a[4]="Bastar|Bijapur|Bilaspur|Dantewada|Dhamtari|Durg|Jashpur|Janjgir-Champa|Korba|Koriya|Kanker|Kabirdham (Kawardha)|Mahasamund|Narayanpur|Raigarh|Rajnandgaon|Raipur|Surguja";
s_a[5]="North Goa|South Goa";
s_a[6]="Ahmedabad|Amreli district|Anand|Banaskantha|Bharuch|Bhavnagar|Dahod|The Dangs|Gandhinagar|Jamnagar|Junagadh|Kutch|Kheda|Mehsana|Narmada|Navsari|Patan|Panchmahal|Porbandar|Rajkot|Sabarkantha|Surendranagar|Surat|Vyara|Vadodara|Valsad";
s_a[7]="Ambala|Bhiwani|Faridabad|Fatehabad|Gurgaon|Hissar|Jhajjar|Jind|Karnal|Kaithal|Kurukshetra|Mahendragarh|Mewat|Palwal|Panchkula|Panipat|Rewari|Rohtak|Sirsa|Sonipat|Yamuna Nagar ";
s_a[8]="Bilaspur|Chamba|Hamirpur|Kangra|Kinnaur|Kullu|Lahaul and Spiti|Mandi|Shimla|Sirmaur|Solan|Una";
s_a[9]="Anantnag|Badgam|Bandipora|Baramulla|Doda|Ganderbal|Jammu|Kargil|Kathua|Kishtwar|Kupwara|Kulgam|Leh|Poonch|Pulwama|Rajauri|Ramban|Reasi|Samba|Shopian|Srinagar|Udhampur";
s_a[10]="Bokaro|Chatra|Deoghar|Dhanbad|Dumka|East Singhbhum|Garhwa|Giridih|Godda|Gumla|Hazaribag|Jamtara|Khunti|Koderma|Latehar|Lohardaga|Pakur|Palamu|Ramgarh|Ranchi|Sahibganj|Seraikela Kharsawan|Simdega|West Singhbhum";
s_a[11]="Bagalkot|Bangalore Rural|Bangalore Urban|Belgaum|Bellary|Bidar|Bijapur|Chamarajnagar|Chikkamagaluru|Chikkaballapur|Chitradurga|Davanagere|Dharwad|Dakshina Kannada|Gadag|Gulbarga|Hassan|Haveri district|Kodagu|Kolar|Koppal|Mandya|Mysore|Raichur|Shimoga|Tumkur|Udupi|Uttara Kannada|Ramanagara|Yadgir";
s_a[12]="Alappuzha|Ernakulam|Idukki|Kannur|Kasaragod|Kollam|Kottayam|Kozhikode|Malappuram|Palakkad|Pathanamthitta|Thrissur|Thiruvananthapuram|Wayanad";
s_a[13]="Alirajpur|Anuppur|Ashok Nagar|Balaghat|Barwani|Betul|Bhind|Bhopal|Burhanpur|Chhatarpur|Chhindwara|Damoh|Datia|Dewas|Dhar|Dindori|Guna|Gwalior|Harda|Hoshangabad|Indore|Jabalpur|Jhabua|Katni|Khandwa (East Nimar)|Khargone (West Nimar)|Mandla|Mandsaur|Morena|Narsinghpur|Neemuch|Panna|Rewa|Rajgarh|Ratlam|Raisen|Sagar|Satna|Sehore|Seoni|Shahdol|Shajapur|Sheopur|Shivpuri|Sidhi|Singrauli|Tikamgarh|Ujjain|Umaria|Vidisha";
s_a[14]="Ahmednagar|Akola|Amravati|Aurangabad|Bhandara|Beed|Buldhana|Chandrapur|Dhule|Gadchiroli|Gondia|Hingoli|Jalgaon|Jalna|Kolhapur|Latur|Mumbai City|Mumbai suburban|Nandurbar|Nanded|Nagpur|Nashik|Osmanabad|Parbhani|Pune|Raigad|Ratnagiri|Sindhudurg|Sangli|Solapur|Satara|Thane|Wardha|Washim|Yavatmal";
s_a[15]="Bishnupur|Churachandpur|Chandel|Imphal East|Senapati|Tamenglong|Thoubal|Ukhrul|Imphal West";
s_a[16]="East Garo Hills|East Khasi Hills|Jaintia Hills|Ri Bhoi|South Garo Hills|West Garo Hills|West Khasi Hills";
s_a[17]="Aizawl|Champhai|Kolasib|Lawngtlai|Lunglei|Mamit|Saiha|Serchhip";
s_a[18]="Dimapur|Kohima|Mokokchung|Mon|Phek|Tuensang|Wokha|Zunheboto";
s_a[19]="Angul|Boudh (Bauda)|Bhadrak|Balangir|Bargarh (Baragarh)|Balasore|Cuttack|Debagarh (Deogarh)|Dhenkanal|Ganjam|Gajapati|Jharsuguda|Jajpur|Jagatsinghpur|Khordha|Kendujhar (Keonjhar)|Kalahandi|Kandhamal|Koraput|Kendrapara|Malkangiri|Mayurbhanj|Nabarangpur|Nuapada|Nayagarh|Puri|Rayagada|Sambalpur|Subarnapur (Sonepur)|Sundergarh";
s_a[20]="Amritsar|Barnala|Bathinda|Firozpur|Faridkot|Fatehgarh Sahib|Fazilka|Gurdaspur|Hoshiarpur|Jalandhar|Kapurthala|Ludhiana|Mansa|Moga|Sri Muktsar Sahib|Pathankot|Patiala|Rupnagar|Ajitgarh (Mohali)|Sangrur|Nawanshahr|Tarn Taran";
s_a[21]="Ajmer|Alwar|Bikaner|Barmer|Banswara|Bharatpur|Baran|Bundi|Bhilwara|Churu|Chittorgarh|Dausa|Dholpur|Dungapur|Ganganagar|Hanumangarh|Jhunjhunu|Jalore|Jodhpur|Jaipur|Jaisalmer|Jhalawar|Karauli|Kota|Nagaur|Pali|Pratapgarh|Rajsamand|Sikar|Sawai Madhopur|Sirohi|Tonk|Udaipur";
s_a[22]="East Sikkim|North Sikkim|South Sikkim|West Sikkim";
s_a[23]="Ariyalur|Chennai|Coimbatore|Cuddalore|Dharmapuri|Dindigul|Erode|Kanchipuram|Kanyakumari|Karur|Madurai|Nagapattinam|Nilgiris|Namakkal|Perambalur|Pudukkottai|Ramanathapuram|Salem|Sivaganga|Tirupur|Tiruchirappalli|Theni|Tirunelveli|Thanjavur|Thoothukudi|Tiruvallur|Tiruvarur|Tiruvannamalai|Vellore|Viluppuram|Virudhunagar";
s_a[24]="Manchiryala|Adilabad|Nirmal|Karimnagar|Peddapally|Jagityal|Mahabubabad|Warangal|Hanmakonda|Bhoopal Pally|Siddipet|Medak|Sangareddy|Nizamabad|Kamareddy|Nalgonda|Suryapet|Yadagiri";
s_a[25]="Dhalai|North Tripura|South Tripura|Khowai|West Tripura";
s_a[26]="Agra|Allahabad|Aligarh|Ambedkar Nagar|Auraiya|Azamgarh|Barabanki|Budaun|Bagpat|Bahraich|Bijnor|Ballia|Banda|Balrampur|Bareilly|Basti|Bulandshahr|Chandauli|Chhatrapati Shahuji Maharaj Nagar|Chitrakoot|Deoria|Etah|Kanshi Ram Nagar|Etawah|Firozabad|Farrukhabad|Fatehpur|Faizabad|Gautam Buddh Nagar|Gonda|Ghazipur|Gorakhpur|Ghaziabad|Hamirpur|Hardoi|Mahamaya Nagar|Jhansi|Jalaun|Jyotiba Phule Nagar|Jaunpur district|Ramabai Nagar (Kanpur Dehat)|Kannauj|Kanpur|Kaushambi|Kushinagar|Lalitpur|Lakhimpur Kheri|Lucknow|Mau|Meerut|Maharajganj|Mahoba|Mirzapur|Moradabad|Mainpuri|Mathura|Muzaffarnagar|Panchsheel Nagar district (Hapur)|Pilibhit|Shamli|Pratapgarh|Rampur|Raebareli|Saharanpur|Sitapur|Shahjahanpur|Sant Kabir Nagar|Siddharthnagar|Sonbhadra|Sant Ravidas Nagar|Sultanpur|Shravasti|Unnao|Varanasi";
s_a[27]="Almora|Bageshwar|Chamoli|Champawat|Dehradun|Haridwar|Nainital|Pauri Garhwal|Pithoragarh|Rudraprayag|Tehri Garhwal|Udham Singh Nagar|Uttarkashi";
s_a[28]="Birbhum|Bankura|Bardhaman|Darjeeling|Dakshin Dinajpur|Hooghly|Howrah|Jalpaiguri|Cooch Behar|Kolkata|Maldah|Paschim Medinipur|Purba Medinipur|Murshidabad|Nadia|North 24 Parganas|South 24 Parganas|Purulia|Uttar Dinajpur";

function print_state(state_id){
       // given the id of the <select> tag as function argument, it inserts <option> tags
       var option_str = document.getElementById(state_id);
       option_str.length=0;
       option_str.options[0] = new Option('Select State','');
       option_str.selectedIndex = 0;
       for (var i=0; i<state_arr.length; i++) {
              option_str.options[option_str.length] = new Option(state_arr[i],state_arr[i]);
       }
}

function print_city(city_id, city_index){
       var option_str = document.getElementById(city_id);
       option_str.length=0;      // Fixed by Julian Woods
       option_str.options[0] = new Option('Select City','');
       option_str.selectedIndex = 0;
       var city_arr = s_a[city_index].split("|");
       for (var i=0; i<city_arr.length; i++) {
              option_str.options[option_str.length] = new Option(city_arr[i],city_arr[i]);
       }
}
