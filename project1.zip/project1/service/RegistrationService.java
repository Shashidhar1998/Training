package com.service;

import org.apache.log4j.Logger;
import org.springframework.orm.hibernate5.HibernateTemplate;

import com.pojo.loginmodel;

public class RegistrationService {

	private HibernateTemplate hibernateTemplate;

 
    private RegistrationService() { }
 
    public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
        this.hibernateTemplate = hibernateTemplate;
    }

    
    @SuppressWarnings( { "unchecked", "deprecation" } )
    public boolean registerUser(loginmodel obj)
    {
    	
   	
    	hibernateTemplate.save(obj);
    	//hibernateTemplate.getSessionFactory().getCurrentSession().getTransaction().commit();
    	
    	
    	return true;
    	
    	
    }
	
}
