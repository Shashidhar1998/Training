package com.service;

import org.apache.catalina.Session;
import org.apache.log4j.Logger;
import org.springframework.orm.hibernate5.HibernateTemplate;

import com.pojo.addhospitalmodel;
import com.pojo.loginmodel;

public class RegistrationService {

	private HibernateTemplate hibernateTemplate;

 
    private RegistrationService() { }
 
    public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
        this.hibernateTemplate = hibernateTemplate;
    }

 
    public boolean registerUser(loginmodel obj)
    {
    	
   	    boolean valid= false;
   	    try
   	    {
    	hibernateTemplate.save(obj);
    	valid = true;
   	    }
   	 catch(Exception e)
        {
        	System.out.println("Registering In the Auth Catch ");
        	e.printStackTrace();
        }
    	//hibernateTemplate.getSessionFactory().getCurrentSession().getTransaction().commit();
    	
    	
    	return valid;
    	
    	
    }

	public boolean registerhospital(loginmodel log, addhospitalmodel userobj) {
		// TODO Auto-generated method stub
		 System.out.println("In the Auth Service ");
        System.out.println("\n\nTo check data in email  :"+log.getEmail());
        System.out.println("\n\nTo check data in email  :"+log.getContactNumber());
        System.out.println("\n\nTo check data in email  :"+log.getPassword());
        System.out.println("\n\nTo check data in email  :"+log.getUserID());
        try
        {
        	hibernateTemplate.save(userobj);
        	hibernateTemplate.save(log);
        	//hibernateTemplate.flush();
        }
        catch(Exception e)
        {
        	
        	System.out.println("In the Auth Catch ");
        	e.printStackTrace();
        }
		//hibernateTemplate.save(userobj);
		return true;
	}

	public boolean registerhospital1(loginmodel log) {
		// TODO Auto-generated method stub
		//hibernateTemplate1.save(log);
		 System.out.println("In the Auth Service 23 ");
		return true;
	}



	
	
	
}
