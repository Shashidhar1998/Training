package com.controller;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.service.AuthService;
import com.pojo.loginmodel;

@Component
@Controller
@RequestMapping("/user")
public class LoginController {

	 @Autowired
	    private AuthService authenticateService; 
	 
 
	
	    @RequestMapping(value = "/validate", method = RequestMethod.POST)
	    public String validateUsr(@RequestParam("username")String username, @RequestParam("password")String password,RedirectAttributes redirectAttributes) {

	    	
	        System.out.println("Before saving in the database...");
	        
	        boolean isValid = authenticateService.findUser(username, password);
	    	
	        System.out.println("After saving in the db...");
	         
	        if(isValid) {
	        	
	        	return "dashboard";
	        } else {
	        	return "index";
	        }
	 
	        
	    }
/*	    @RequestMapping(value = "/dashboard1")
	    public String dashboard1()
	    {
	    	return "dashboard";
	    }
	    @RequestMapping(value = "/index1")
	    public String index1()
	    {
	    	return "index";
	    }
 */
	
}
