package com.pojo;

import javax.persistence.Column;
//import javax.persistence.Entity;
//import javax.persistence.Id;
//import javax.persistence.Table;


import java.io.Serializable;


//@Entity
//@Table(name = "adminlogin")
public class loginmodel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	//@Id
	//@Column(name = "UserID")
	private String UserID;
	
	//@Id
	//@Column(name = "Password")
	private String Password;
	
	//@Id
	//@Column(name = "Email")
	private String Email;
	
	//@Id
	@Column(name = "ContactNumber")
	private String ContactNumber;

	public String getUserID() {
		return UserID;
	}

	public void setUserID(String userID) {
		UserID = userID;
	}

	public String getPassword() {
		return Password;
	}

	public void setPassword(String password) {
		Password = password;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}

	public String getContactNumber() {
		return ContactNumber;
	}

	public void setContactNumber(String contactNumber) {
		ContactNumber = contactNumber;
	}
	
	
	
}
